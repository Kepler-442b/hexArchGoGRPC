This directory contains forked versions of go standard packages.  They are
manually copied here.
