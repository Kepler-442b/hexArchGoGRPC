// Package psort includes functions for parallel sorting.
package psort
