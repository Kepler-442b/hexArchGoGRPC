This is a simple Go wrapper for [libdeflate](https://github.com/ebiggers/libdeflate).
